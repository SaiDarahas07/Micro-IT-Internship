 A simple blog website built with Flask, featuring user authentication, post creation, and categories.

 ## Setup
 1. Install dependencies: `pip install -r requirements.txt`
 2. Run the app: `python main.py`

 ## Usage
 - **Homepage**: Access at `http://localhost:5000/` to view posts.
   - *Screenshot*:  
     ![Homepage](screenshots/homepage.png)
 - **Create Post**: Navigate to `/post/new` to create a new post.
   - *Screenshot*:  
     ![Create Post](screenshots/create_post.png)
 - **Login**: Use `/login` to log in (authentication to be implemented).
   - *Screenshot*:  
     ![Login](screenshots/login.png)

 ## Next Steps
 - Add user authentication with Flask-Login.
 - Implement comments and categories.
 - Create an admin panel for managing content.
 